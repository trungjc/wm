# Gulp Starter for CSS Tricks Tutorial  

This repo is a gulp starter for this CSS Tricks tutorial. 

Remember to do run the `npm install` command after cloning this repo :) 